# Labs

This folder contains practical demonstrations of specific functionality from the portfolio project.

## Included Demos

- `ejemplo-toggle.html`: A standalone HTML example showing how the dark/light mode toggle works using JavaScript and localStorage.

These labs are meant to showcase individual features in isolation, useful for testing or educational purposes.
